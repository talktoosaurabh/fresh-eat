<?php $__env->startSection('content'); ?>
<?php
$groupings = ['new' => 'New Arrivals','deals' => 'Deal of the Month', 'savers' => 'Todays saver','best_rate' => 'Best Rates' ,'popular' => 'Most Popular'];
?>
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Create Product</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php if(Session::has('flash_success')): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_success')); ?>

                  </div>
              <?php endif; ?>
              <?php if(Session::has('flash_error')): ?>
                  <div class="alert alert-danger">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_error')); ?>

                  </div>
              <?php endif; ?>
              <div class="container">
                <form method="get" action="">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label for="category_id">Select Category <span class="required">*</span></label>
                          <select name="category_id" class="form-control" onchange="this.form.submit()">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(isset($_REQUEST['category_id']) && $_REQUEST['category_id'] != ''): ?>
                                  <option value="<?php echo e($category->id); ?>" <?php if(@$_REQUEST['category_id'] == $category->id): ?> selected <?php endif; ?> ><?php echo e($category->name); ?></option>
                              <?php else: ?>
                                  <option value="<?php echo e($category->id); ?>" <?php if(@$data->category_id == $category->id): ?> selected <?php endif; ?> ><?php echo e($category->name); ?></option>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    </div>
                </form>
                <form enctype="multipart/form-data" role="form" id="myform" method="post" action="<?php echo e(route('products.update',$data->id)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?> 
                  <?php if(isset($_REQUEST['category_id']) && $_REQUEST['category_id'] != ''): ?>
                    <input type="hidden" name="parent_category_id" value="<?php echo e(@$_REQUEST['category_id']); ?>">
                  <?php else: ?>
                    <input type="hidden" name="parent_category_id" value="<?php echo e(@$data->category_id); ?>">
                  <?php endif; ?>
                 <input type="hidden" id="id" value="<?php echo e($data->id); ?>"> 
                   <div class="row">
                      <div class="col-sm-12">
                            <div class="form-group">
                              <label>Select Subcategory <span class="required">*</span></label><br>
                              <?php if(count($subcategories)): ?>
                                <select name="subcategory_id" class="form-control">
                                  <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option <?php if(@$data->subcategory_id == $subcategory->id): ?> selected <?php endif; ?> value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              <?php else: ?>
                                No Subcategory Found.  Please Create a Subcategory for this category <a target="_blank" href="<?php echo e(url('/')); ?>/admin/subcategory/create">Here</a>
                              <?php endif; ?>
                            </div>  
                            <div class="form-group">
                              <label for="price">Product Name <span class="required">*</span></label>
                              <input type="text" name="productname" id="productname" class="form-control" placeholder="Enter Product Name" value="<?php echo e($data->name); ?>" />
                              <?php if($errors->has('productname')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('productname')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                            </div>
                            <div class="form-group">
                              <label for="groups">Select groups <span class="required">*</span></label>
                              <?php 
                              $selected_group = explode(",", $data->groups);
                              ?>
                              <?php $__currentLoopData = $groupings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(in_array($p,$selected_group)): ?>
                              <div class="col-sm-2 flex_check">
                                <input type="checkbox" name="groups[]" class="form-control check_css" value="<?php echo e($p); ?>" checked="checked" /> 
                                <span><?php echo e($group); ?></span>
                              </div>
                              <?php else: ?>
                              <div class="col-sm-2 flex_check">
                                <input type="checkbox" name="groups[]" class="form-control check_css" value="<?php echo e($p); ?>"/> 
                                <span><?php echo e($group); ?></span>
                              </div>
                              <?php endif; ?>
                        
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group">
                            <label class="radio-inline" for="size_id">
                              Select unit for weight <span class="required">*</span><br>
                              <br>
                              <input type="radio" value="gm" name="unit_id" <?php if($data->weight_units == 'gm'): ?> checked <?php endif; ?>> Grams(gm)
                              <input type="radio" value="kg" name="unit_id" <?php if($data->weight_units == 'kg'): ?> checked <?php endif; ?>> Kilograms(kg)
                            </label>
                          </div>
                          <div class="form-group">
                            <label for="price">Add Weight(per weight for price)</label>
                            <input type="number" name="weight" id="weight" class="form-control" placeholder="Enter weight" value="<?php echo e($data->weight); ?>"/>
                            <?php if($errors->has('weight')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('weight')); ?></strong>
                                </span>
                            <?php endif; ?>  
                          </div>
                          <div class="form-group">
                            <label for="price">Add available Stock (in weight)</label>
                            <input type="number" name="stock_count" id="stock_count" class="form-control" placeholder="Enter stock" value="<?php echo e($data->stock_count); ?>"/>
                            <?php if($errors->has('stock_count')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('stock_count')); ?></strong>
                                </span>
                            <?php endif; ?>  
                          </div>
                            <div class="form-group">
                              <label for="price">Mrp Price <span class="required">*</span></label>
                              <input type="number" min="0" name="mrp_price" id="mrp_price" class="form-control" placeholder="Enter Mrp Price" value="<?php echo e($data->mrp_price); ?>" />
                              <?php if($errors->has('mrp_price')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('mrp_price')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                            </div>
                            <div class="form-group">
                              <label for="price">Selling Price <span class="required">*</span></label>
                              <input type="number" min="0" name="selling_price" id="selling_price" class="form-control" placeholder="Enter Selling Price" value="<?php echo e($data->selling_price); ?>" />
                              <?php if($errors->has('selling_price')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('selling_price')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                            </div>
                            <div class="form-group">
                              <label for="description">Description <span class="required">*</span></label>
                              <textarea class="form-control" id="description" name="description"><?php echo e($data->description); ?></textarea>
                              <span style="font-size: 17px;" id="required_description"></span>
                              <script>
                                    CKEDITOR.replace( 'description' );
                              </script>
                              <?php if($errors->has('description')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('description')); ?></strong>
                                  </span>
                              <?php endif; ?> 
                            </div>
                            <div class="form-group">
                              <label for="additional_info">Additional Information </label>
                              <textarea class="form-control" id="additional_info" name="additional_information"><?php echo $data->additional_information; ?></textarea>
                              <script>
                                    CKEDITOR.replace( 'additional_information' );
                              </script>

                            </div>
                            <div class="form-group">
                              <label for="shipping_returns">Shipping returns </label>
                              <textarea class="form-control" id="shipping_returns" name="shipping_returns"><?php echo $data->shipping_returns; ?></textarea>
                              <script>
                                    CKEDITOR.replace( 'shipping_returns' );
                              </script>
                            </div>
                            <div class="form-group">
                              <label for="price">Status <span class="required">*</span></label><br>
                                <label for="chkYes">
                                  <input type="radio" class="productstatus" value="Active" name="productstatus" <?php if($data->status == 'Active'): ?> checked <?php endif; ?>/>
                                  <?php if($errors->has('productstatus')): ?>
                                    <span class="required">
                                        <strong><?php echo e($errors->first('productstatus')); ?></strong>
                                    </span>
                                <?php endif; ?>  
                                  Active
                              </label>
                              <label for="chkNo">
                                  <input type="radio" class="productstatus" value="InActive" name="productstatus" <?php if($data->status == 'InActive'): ?> checked <?php endif; ?> />
                                  <?php if($errors->has('productstatus')): ?>
                                    <span class="required">
                                        <strong><?php echo e($errors->first('productstatus')); ?></strong>
                                    </span>
                                <?php endif; ?>  
                                  Inactive
                              </label>
                            </div>
                             <div class="form-group">
                              <button id="submit" type="submit" class="btn btn-primary">Update Product</button>
                            </div>
                      </div>
                   </div>
                </form>
                <form enctype="multipart/form-data" method="post" action="<?php echo e(url('admin/products/addMoreImages')); ?>">
                  <?php echo csrf_field(); ?>
                  <h3>Add More Images</h3>
                  <input type="hidden" name="product_id" value="<?php echo e($data->id); ?>">
                  <div class="form-group">
                    <label for="images">Choose Image <span class="required">*</span></label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" name="images[]" class="custom-file-input" id="images" multiple>
                          <?php if($errors->has('images')): ?>
                            <span class="required">
                                <strong><?php echo e($errors->first('images')); ?></strong>
                            </span>
                          <?php endif; ?>  
                          <label class="custom-file-label" for="images">Choose image file</label>
                        </div>
                      </div>
                  </div>
                  <div class="form-group">
                    <button id="submit" type="submit" class="btn btn-primary">Upload Images</button>
                  </div>
                </form>
                <h2>Product Images</h2>
                <div class="row">
                  <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-3">
                    <div style="position: relative;">
                      <img src="<?php echo e(URL::to('/')); ?>/public/assets/images/products/<?php echo e(@$row->image); ?>" style="width: 100%;" />
                      <button style="position: absolute; right: 0px;
                        font-size: 18px;" id="delete-multiple-image<?php echo e($row->id); ?>" form="resource-delete-<?php echo e($row->id); ?>"><i style="color: red;" class="fas fa-trash-alt"></i>
                      </button>  
                      </div>
                    <div>
                      
                      <form action="<?php echo e(url('admin/products/delete-multiple-image')); ?>?id=<?php echo e($row->id); ?>" id="resource-delete-<?php echo e($row->id); ?>" style="display: inline-block;" onSubmit="return confirm('Are you sure you want to delete this item?');" method="post">
                      <?php echo csrf_field(); ?>
                      </form>
                    </div>
                    <div>
                      <label><input type="radio" value="<?php echo e($row->id); ?>" id="featureimage<?php echo e($row->id); ?>" <?php if($row->is_featured == 1): ?> checked <?php endif; ?> name="featureimage">Make Featured Image</label>
                    </div>
                  </div>
                  <input type="hidden" id="id" value="<?php echo e($data->id); ?>">
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
          </div>
        </div>
       </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<script>
<?php foreach($images as $row){ ?>
  $('#featureimage<?php echo $row->id; ?>').on('click', function (ev) {
    var imageId = $('#featureimage<?php echo $row->id; ?>').val();
    var id = $('#id').val();
    $.ajax({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      type: "POST",
      url: "<?php echo e(url('admin/products/makeFeatureImage')); ?>",
      data: {"imageId":imageId,"id":id},
      dataType: "json",
      success: function (data) {
        location.reload();
        if (data.succ == 1) {
            location.reload();
        } 
      }
    });
  });
  <?php } ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>
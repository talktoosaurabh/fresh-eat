<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CorporateEnquiry;
use App\Models\DealershipBooking;

class PageController extends Controller
{
    public function about()
    {
        $title = "About | Terra Kotta";
        $desc = "About | Terra Kotta";
    	return view('pages.about',compact('title','desc'));
    }
	 public function corporateEnquiry()
    {
        $title = "Corporate Enquiry | Terra Kotta";
        $desc = "Corporate Enquiry | Terra Kotta";
    	return view('pages.corporate-enquiry',compact('title','desc'));
    }
	 public function dealershipBooking()
    {
        $title = "Dealership Booking | Terra Kotta";
        $desc = "Dealership Booking | Terra Kotta";
    	return view('pages.dealership-booking',compact('title','desc'));
    }
    public function contact()
    {
        $title = "Contact | Terra Kotta";
        $desc = "Contact | Terra Kotta";
    	return view('pages.contact',compact('title','desc'));
    }

    public function blogs(){
        $title = "Blogs | Fresh Eat";
        $desc = "Blogs | Fresh Eat";
        return view('pages.blogs',compact('title','desc')); 
    }

    public function privacyPolicy()
    {
        $title = "Privacy Policy | Terra Kotta";
        $desc = "Privacy Policy | Terra Kotta";
    	return view('pages.privacy-policy',compact('title','desc'));
    }

    public function termsCondtion()
    {
        $title = "Terems and Condition | Terra Kotta";
        $desc = "Terems and Condition | Terra Kotta";
    	return view('pages.terms-condition',compact('title','desc'));
    }

    public function saveDealershipBooking(Request $request)
    {
        $contact = new DealershipBooking;
        $contact->firstname = $request->firstname;
        $contact->lastname = $request->lastname;
        $contact->company_name = $request->company_name;
        $contact->address = $request->address;
        $contact->city = $request->city;
        $contact->state = $request->state;
        $contact->contact_number = $request->contact_number;
        $contact->email_address = $request->email_address;
        $contact->business_desc = $request->business_desc;
        $contact->save();
        return back()->with('flash_success_conact', 'Thank You We will get back to you');
    }

    public function saveCorporateEnquiry(Request $request)
    {
        $contact = new CorporateEnquiry;
        $contact->firstname = $request->firstname;
        $contact->lastname = $request->lastname;
        $contact->company_name = $request->company_name;
        $contact->address = $request->address;
        $contact->city = $request->city;
        $contact->state = $request->state;
        $contact->contact_number = $request->contact_number;
        $contact->email_address = $request->email_address;
        $contact->business_desc = $request->business_desc;
        $contact->save();
        return back()->with('flash_success_conact', 'Thank You We will get back to you');
    }
}

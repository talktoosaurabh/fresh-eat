 <?php $__env->startSection('content'); ?>
<div class="page-header text-center" style="background-image: url('<?php echo e(asset('public/assets/images/page-header-bg.jpg')); ?>')">
  <div class="container">
    <h1 class="page-title">My Account<span>Shop</span></h1>
  </div><!-- End .container -->
</div><!-- End .page-header -->
  <nav aria-label="breadcrumb" class="breadcrumb-nav mb-3">
      <div class="container">
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">My Account</li>
          </ol>
      </div><!-- End .container -->
  </nav><!-- End .breadcrumb-nav -->

  <div class="page-content">
    <div class="dashboard">
        <div class="container">
          <?php if(Session::has('flash_success')): ?>
              <div class="alert alert-success">
                  <button type="button" class="close" data-dismiss="alert">×</button>
              <?php echo e(Session::get('flash_success')); ?>

              </div>
          <?php endif; ?>
          <?php if(Session::has('flash_error')): ?>
              <div class="alert alert-danger">
                  <button type="button" class="close" data-dismiss="alert">×</button>
              <?php echo e(Session::get('flash_error')); ?>

              </div>
          <?php endif; ?>
          <div class="row">
            <aside class="col-md-4 col-lg-3">
              <ul class="nav nav-dashboard flex-column mb-3 mb-md-0" role="tablist">
          <li class="nav-item">
              <a class="nav-link active" id="tab-dashboard-link" data-toggle="tab" href="#tab-dashboard" role="tab" aria-controls="tab-dashboard" aria-selected="true">Dashboard</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" id="tab-address-link" data-toggle="tab" href="#tab-address" role="tab" aria-controls="tab-address" aria-selected="false">Addresses</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" id="tab-password-link" data-toggle="tab" href="#tab-password" role="tab" aria-controls="tab-password" aria-selected="false">Change password</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" id="tab-account-link" data-toggle="tab" href="#tab-account" role="tab" aria-controls="tab-account" aria-selected="false">Account Details</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" >Sign Out</a>
          </li>
          <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
             <?php echo e(csrf_field()); ?>

          </form>
      </ul>
            </aside><!-- End .col-lg-3 -->

            <div class="col-md-8 col-lg-9">
              <div class="tab-content">
          <div class="tab-pane fade show active" id="tab-dashboard" role="tabpanel" aria-labelledby="tab-dashboard-link">
            <p>Hello <span class="font-weight-normal text-dark">User</span> (not <span class="font-weight-normal text-dark">User</span>? <a href="#">Log out</a>) 
            <br>
            From your account dashboard you can view your, manage your <a href="#tab-address" class="tab-trigger-link">shipping and billing addresses</a>, and <a href="#tab-account" class="tab-trigger-link">edit your password and account details</a>.</p>
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class="px-3 py-3">Order Id</th>
                  <th class="px-3 py-3">Order Details</th>
                  <th class="px-3 py-3">Total</th>
                  <th class="px-3 py-3">Status</th>
                </tr>
                </thead>
                <tbody>
                <?php if($all_orders->total() > 0): ?>
                <?php $__currentLoopData = $all_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="px-3 py-3">
                  <code><?php echo e($orders->order_id); ?></code>
                  </td>
                  <td class="px-3 py-3">
                    
                    <?php $__currentLoopData = $orders->order_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <p><?php echo e($list->get_product()->name); ?> : <b><?php echo e(format_weight($list->quantity).'kg x '.format_money($list->get_product()->mrp_price).' = '.format_money($list->mrp_price)); ?></b></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                  </td>
                  <td class="px-3 py-3">
                    <?php echo e(format_money($orders->payable_price)); ?>

                  </td>
                  <td class="px-3 py-3">
                    <?php if($orders->status == "received"): ?> 
                      <span class="badge badge-info">Received</span>
                    <?php elseif($orders->status == "packed"): ?> 
                      <span class="badge badge-warning">Packed</span>
                    <?php elseif($orders->status == "shipped"): ?>  
                      <span class="badge badge-dark">On the way</span>
                    <?php elseif($orders->status == "delivered"): ?>
                      <span class="badge badge-success">Delivered</span>
                    <?php elseif($orders->status == "cancelled"): ?>
                      <?php if($orders->cancelled_by == 'admin'): ?>
                      <span class="badge badge-danger">Cancelled by Admin</span>
                      <?php else: ?>
                      <span class="badge badge-danger">Cancelled by Customer</span>
                      <?php endif; ?>
                    <?php endif; ?>
                    <?php if($orders->status == "received"): ?>
                    <a href="<?php echo e(url('/cancel_order/'.$orders->id)); ?>" class="badge badge-danger">Cancel order</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>

            <div class="row">
              <div class="col-sm-6">
                <?php echo e($all_orders->links()); ?>

              </div>
              <div class="col-sm-2 offset-md-4">
                <a href="<?php echo e(url('/all_products')); ?>" class="btn btn-outline-primary-2"><span>GO SHOP</span><i class="icon-long-arrow-right"></i></a>
              </div>
            </div>
          
          </div><!-- .End .tab-pane -->
          <div class="tab-pane fade" id="tab-password" role="tabpanel" aria-labelledby="tab-password-link">
            <form action="<?php echo e(url('/user/updatePassword')); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="col-sm-12">
                  <label>Current password (leave blank to leave unchanged)</label>
                  <input type="password" class="form-control" name="current_password">
                  <?php if($errors->has('current_password')): ?>
                      <span class="required">
                          <strong><?php echo e($errors->first('current_password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>
                
                <div class="col-sm-12">
                  <label>New password (leave blank to leave unchanged)</label>
                  <input type="password" class="form-control" name="password">
                  <?php if($errors->has('password')): ?>
                      <span class="required">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>
                <div class="col-sm-12">
                  <label>Confirm new password</label>
                  <input type="password" class="form-control mb-2" name="confirm_password">
                  <?php if($errors->has('confirm_password')): ?>
                      <span class="required">
                          <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>

                  <button type="submit" class="btn btn-outline-primary-2">
                    <span>SAVE CHANGES</span>
                  <i class="icon-long-arrow-right"></i>
                  </button>
            </form>
          </div><!-- .End .tab-pane -->
          <div class="tab-pane fade" id="tab-address" role="tabpanel" aria-labelledby="tab-address-link">
            <p>The following addresses will be used on the checkout page by default.</p>

            <div class="row">
              <div class="col-lg-6">
                <div class="card card-dashboard">
                  <div class="card-body">
                    <h3 class="card-title">User information</h3><!-- End .card-title -->

                  <p><?php echo e(Auth::user()->name ?? ''); ?><br>
                  <?php echo e(Auth::user()->country ?? ''); ?><br>
                  <?php echo e(Auth::user()->phone ?? ''); ?><br>
                  <?php echo e(Auth::user()->email ?? ''); ?><br>
                    
                  <a href="#tab-account" class="tab-trigger-link">Edit <i class="icon-edit"></i></a></p>
                  </div><!-- End .card-body -->
                </div><!-- End .card-dashboard -->
              </div><!-- End .col-lg-6 -->

              <div class="col-lg-6">
                <div class="card card-dashboard">
                  <div class="card-body">
                    <h3 class="card-title">Billing Address</h3><!-- End .card-title -->

                  <p><?php echo e(Auth::user()->street ?? ''); ?>

                  <?php echo e(Auth::user()->city ?? ''); ?><br>
                  <?php echo e(Auth::user()->state ?? ''); ?><br>
                  <?php echo e(Auth::user()->country ?? ''); ?><br>
                  <?php echo e(Auth::user()->pincode ?? ''); ?><br>
                  <a href="#tab-account" class="tab-trigger-link">Edit <i class="icon-edit"></i></a></p>
                  </div><!-- End .card-body -->
                </div><!-- End .card-dashboard -->
              </div><!-- End .col-lg-6 -->
            </div><!-- End .row -->
          </div><!-- .End .tab-pane -->

          <div class="tab-pane fade" id="tab-account" role="tabpanel" aria-labelledby="tab-account-link">
            <form action="<?php echo e(url('/user/updateAccount')); ?>" method="POST">
              <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-sm-6">
                        <label>Name *</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->name ?? ''); ?>" required >
                      </div><!-- End .col-sm-6 -->

                      <div class="col-sm-6">
                        <label>Email address *</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e(Auth::user()->email ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                    </div><!-- End .row -->
                    <div class="row">
                      <div class="col-sm-6">
                        <label>Phone *</label>
                        <input type="text" class="form-control" name="phone" value="<?php echo e(Auth::user()->phone ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->

                      <div class="col-sm-6">
                        <label>Pin code</label>
                        <input type="text" class="form-control" name="pincode" value="<?php echo e(Auth::user()->pincode ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                    </div><!-- End .row -->
                    <div class="row">
                      <div class="col-sm-12">
                        <label>Address / Street *</label>
                        <input type="text" class="form-control" name="street" value="<?php echo e(Auth::user()->street ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <label>City</label>
                        <input type="text" class="form-control" name="city" value="<?php echo e(Auth::user()->city ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                      <div class="col-sm-6">
                        <label>State *</label>
                        <input type="text" class="form-control" name="state" value="<?php echo e(Auth::user()->state ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <label>Country *</label>
                        <input type="text" class="form-control" name="country" value="<?php echo e(Auth::user()->country ?? ''); ?>" required>
                      </div><!-- End .col-sm-6 -->
                    </div>
                    <button type="submit" class="btn btn-outline-primary-2">
                      <span>SAVE CHANGES</span>
                    <i class="icon-long-arrow-right"></i>
                    </button>
                  </form>
          </div><!-- .End .tab-pane -->
          </div>
            </div><!-- End .col-lg-9 -->
          </div><!-- End .row -->
        </div><!-- End .container -->
      </div><!-- End .dashboard -->
  </div><!-- End .page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/user/myprofile.blade.php ENDPATH**/ ?>
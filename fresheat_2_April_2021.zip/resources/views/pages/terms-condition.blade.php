@extends('layouts.app')

@section('content')
<div class="section-title-container mb-70 pt-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <!--=======  section title  =======-->

                <div class="section-title section-title--one text-center">

                    
                    <h1>Terms and Condition</h1>
                    <p class="subtitle">Lorem ipsum dolor sit amet, consectetur cing elit. Suspe ndisse suscipit sagittis leo
                        sit met condimentum estibulum is Suspe ndisse suscipit sagittis leo sit met condimentum estibulorem ipsum
                        dolor sit amet, consectetur cing elit.</p>
                </div>

                <!--=======  End of section title  =======-->
            </div>
        </div>
    </div>
</div>
<!--=====  End of section title container ======-->
@endsection
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Create Category</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php if(Session::has('flash_success')): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_success')); ?>

                  </div>
              <?php endif; ?>
              <?php if(Session::has('flash_error')): ?>
                  <div class="alert alert-danger">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_error')); ?>

                  </div>
              <?php endif; ?>
              <form enctype="multipart/form-data" role="form" id="myform" method="post" action="<?php echo e(route('category.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="container">
                 <div class="row">
                    <div class="col-sm-12">
                          <div class="form-group">
                            <label for="price">Category Name <span class="required">*</span></label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="Enter Category Name" />
                            <?php if($errors->has('name')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>  
                          </div>
                          <div class="form-group">
                             <label for="description">Description <span class="required">*</span></label>
                                <textarea placeholder="Enter Description" rows="5" class="form-control" name="description"><?php echo e(old('description')); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('description')); ?></strong>
                                  </span>
                                <?php endif; ?>  
                            </div>
                            <div class="form-group">
                              <label for="images">Image <span class="required">*</span></label>
                                <div class="input-group">
                                  <div class="custom-file">
                                    <input type="file" name="image" class="custom-file-input" id="image">
                                    <?php if($errors->has('image')): ?>
                                      <span class="required">
                                          <strong><?php echo e($errors->first('image')); ?></strong>
                                      </span>
                                    <?php endif; ?>  
                                    <label class="custom-file-label" for="images">Choose Image</label>
                                  </div>
                                </div>
                            </div>
                          <div class="form-group">
                            <label for="price">Status <span class="required">*</span></label><br>
                              <label for="chkYes">
                                <input type="radio" class="status" value="Active" name="status" checked="" />
                                <?php if($errors->has('status')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('status')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                                Active
                            </label>
                            <label for="chkNo">
                                <input type="radio" class="status" value="InActive" name="status"/>
                                <?php if($errors->has('status')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('status')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                                Inactive
                            </label>
                          </div>
                           <div class="form-group">
                            <button id="submit" type="submit" class="btn btn-primary">Create Category</button>
                          </div>
                    </div>
                 </div>
                </div>
              </form>
          </div>
        </div>
       </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/category/create.blade.php ENDPATH**/ ?>
@extends('admin.layouts.app')

@section('content')
<!-- Main content -->
<div class="content">
  <div class="container-fluid">
     <!-- Main content -->
    <section class="content">
     
    </section>
    <!-- /.content -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">SubCategory</h3>
                <a href="<?php echo e(route('subcategory.create')); ?>" class="btn btn-primary float-right">Create</a>
              </div>
              <?php if(Session::has('flash_success')): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_success')); ?>

                  </div>
              <?php endif; ?>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th>Image</th>
                      <th>Category Name</th>
                      <th>SubCategory Name</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr> 
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $category = \App\Models\Category::where('id',$row->parent_id)->first(); ?>
                    <tr>
                      <td>
                        <?php if(!empty($row->image)): ?>
                        <img src="<?php echo e(URL::to('/')); ?>/public/assets/images/categories/<?php echo e(@$row->image); ?>" style="width: 100px;" />
                        <?php else: ?>
                        <img src="<?php echo e(URL::to('/')); ?>/public/assets/images/fresh_default.jpg" style="width: 50px;" />
                        <?php endif; ?>
                      </td>
                      <td><?php echo e(@$category->name); ?></td>
                      <td><?php echo e(@$row->name); ?></td>
                      <td><?php echo e(@$row->status); ?></td>
                      <td>
                        <a href="<?php echo e(route('subcategory.edit', $row->id)); ?>" class="btn"><i class="fas fa-edit" style="color: blue;"></i></a>
                        <button form="resource-delete-<?php echo e($row->id); ?>"><i style="color: red;" class="fas fa-trash-alt"></i></button>
                        <form id="resource-delete-<?php echo e($row->id); ?>" action="<?php echo e(route('subcategory.destroy', $row->id)); ?>" style="display: inline-block;" onSubmit="return confirm('Are you sure you want to delete this item?');" method="post">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                        </form>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <br>
                <?php echo $data->links(); ?>

              </div>
              <!-- /.card-body -->
              
        </div>
        <!-- /.card -->
        </div>
       </div>
      </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>
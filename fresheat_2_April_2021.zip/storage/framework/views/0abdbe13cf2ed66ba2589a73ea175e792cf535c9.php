<?php $__env->startSection('content'); ?>
<div class="intro-slider-container mb-0">
    <div class="intro-slider owl-carousel owl-theme owl-nav-inside owl-light" data-toggle="owl" 
        data-owl-options='{
            "dots": true,
            "nav": false, 
            "responsive": {
                "1200": {
                    "nav": true,
                    "dots": false
                }
            }
        }'>
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="intro-slide" style="background-image: url(public/assets/images/banners/<?php echo e($ban->image); ?>);">
            <div class="container intro-content">
                <div class="row justify-content-end">
                    <div class="col-auto col-sm-7 col-md-6 col-lg-5">
                        <h3 class="intro-subtitle text-third"><?php echo e($ban->sub_title); ?></h3><!-- End .h3 intro-subtitle -->
                        <h1 class="intro-title"><?php echo e($ban->title); ?></h1>
                        

                        <!-- <div class="intro-price">
                            <sup class="intro-old-price text-white">Rs.349.95</sup>
                            <span class="text-third">
                                Rs.279<sup>.99</sup>
                            </span>
                        </div> -->
                        <?php $amt = $dec = ''; ?>
                        <?php if(!empty($ban->todays_price)): ?>
                            <?php 

                            if(strpos($ban->todays_price, '.') !== false){
                                $amount = explode (".", $ban->todays_price); 
                                $amt = $amount[0];
                                $dec = $amount[1];
                            }else{
                                $amt = $ban->todays_price;
                                $dec = ''; 
                            }
                            ?>
                        <div class="intro-price">
                            <sup class="text-white">Today:</sup>
                            <span class="text-third">
                                Rs.<?php echo e($amt); ?><sup>.<?php echo e($dec); ?></sup>
                            </span>
                        </div><!-- End .intro-price -->
                        <?php endif; ?>
                        

                        <a href="<?php echo e(url('/'.$ban->link_url)); ?>" class="btn btn-primary btn-round">
                            <span><?php echo e($ban->link_title); ?></span>
                            <i class="icon-long-arrow-right"></i>
                        </a>
                    </div><!-- End .col-lg-11 offset-lg-1 -->
                </div><!-- End .row -->
            </div><!-- End .intro-content -->
        </div><!-- End .intro-slide -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div><!-- End .intro-slider owl-carousel owl-simple -->

    <span class="slider-loader"></span><!-- End .slider-loader -->
</div><!-- End .intro-slider-container -->
<?php 
$get_deals = list_products('deals');
$get_savers = list_products('savers',3);
$get_populars = list_products('popular');
$get_new = list_products('new');
$get_best_rates = list_products('best_rate');
$get_arrivals = list_products('new',3);
$get_all_savers = list_products('savers');

?>
<div class="bg-light pt-5 pb-4">
    <div class="container trending-products">
        <div class="heading heading-flex mb-3">
            <div class="heading-left">
                <h2 class="title">Deal Of the Month</h2><!-- End .title -->
            </div><!-- End .heading-left -->

           <div class="heading-right">
                <ul class="nav nav-pills nav-border-anim justify-content-center" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="trending-popular-link" data-toggle="tab" href="#trending-popular-tab" role="tab" aria-controls="trending-popular-tab" aria-selected="true">Most Popular</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="trending-rate-link" data-toggle="tab" href="#trending-rate-tab" role="tab" aria-controls="trending-rate-tab" aria-selected="false">Best Rate</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="trending-new-link" data-toggle="tab" href="#trending-new-tab" role="tab" aria-controls="trending-new-tab" aria-selected="false">New Arrivals</a>
                    </li>
                </ul>
           </div><!-- End .heading-right -->
        </div><!-- End .heading -->

        <div class="row">
            <div class="col-xl-5col d-none d-xl-block">
                <div class="banner">
                    <div class="owl-carousel owl-full carousel-equal-height" data-toggle="owl" 
                            data-owl-options='{
                                "nav": true, 
                                "dots": false,
                                "margin": 20,
                                "loop": false,
                                "responsive": {
                                    "0": {
                                        "items":1
                                    },
                                    "480": {
                                        "items":1
                                    },
                                    "768": {
                                        "items":1
                                    },
                                    "992": {
                                        "items":1
                                    }
                                }
                            }'>
                            <?php if($get_deals->total() > 0): ?>
                            <?php $__currentLoopData = $get_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-top">Top</span>
                                    <a href="<?php echo e(url('/product/'.$deals->slug)); ?>">
                                        <img src="<?php echo e($deals->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" class="btn-product-icon btn-wishlist" onclick="addToWishList(<?php echo $deals->id; ?>)" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" class="btn-product btn-cart" onclick="addToCart(<?php echo $deals->id;?>)" title="Add to cart"><span>add cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$deals->category_slug)); ?>"><?php echo e($deals->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$deals->slug)); ?>"><?php echo e($deals->name); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($deals->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 100%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->
                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- End .owl-carousel -->
            <?php if($get_savers->total() > 0): ?>
            <table class="table table-wishlist table-mobile" style="background: #fff;">
            <thead>
                <tr>
                    <th><h5 class="mb-0 mt-3 pl-3">Top Savers Today</h5></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $get_savers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $savers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="product-col pl-3">
                        <div class="product">
                            <figure class="product-media">
                                <a href="<?php echo e(url('/product/'.$savers->slug)); ?>">
                                    <img src="<?php echo e($savers->product_img); ?>" alt="Product image">
                                </a>
                            </figure>

                            <h3 class="product-title">
                                <a href="<?php echo e(url('/product/'.$savers->slug)); ?>"><?php echo e($savers->name); ?><br><?php echo e(format_money($savers->mrp_price)); ?></a>
                            </h3><!-- End .product-title -->
                        </div><!-- End .product -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <?php endif; ?>
                </div><!-- End .banner -->
            </div><!-- End .col-xl-5col -->

            <div class="col-xl-4-5col">
                <div class="tab-content tab-content-carousel just-action-icons-sm">
                    <div class="tab-pane p-0 fade show active" id="trending-popular-tab" role="tabpanel" aria-labelledby="trending-popular-link">
                        <div class="row">
                            <?php if(!empty($get_populars->total() > 0)): ?>
                            <?php $__currentLoopData = $get_populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2 col-4">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-top">Top</span>
                                    <a href="<?php echo e(url('/product/'.$popular->slug)); ?>">
                                        <img src="<?php echo e($popular->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" onclick="addToWishList(<?php echo $popular->id; ?>)" class="btn-product-icon btn-wishlist" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" onclick="addToCart(<?php echo $popular->id; ?>)" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$popular->category_slug)); ?>"><?php echo e($popular->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$popular->slug)); ?>"><?php echo e($popular->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($popular->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 100%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->

                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <!-- End .owl-carousel -->
                        </div>
                    </div><!-- .End .tab-pane -->
                    <div class="tab-pane p-0 fade" id="trending-rate-tab" role="tabpanel" aria-labelledby="trending-rate-link">
                        <div class="row">
                            <?php if($get_best_rates->total() > 0): ?>
                            <?php $__currentLoopData = $get_best_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2 col-4">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-new">New</span>
                                    <a href="<?php echo e(url('/product/'.$rates->slug)); ?>">
                                        <img src="<?php echo e($rates->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" onclick="addToWishList(<?php echo $rates->id; ?>)" class="btn-product-icon btn-wishlist" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" onclick="addToCart(<?php echo $rates->id; ?>)" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$rates->category_slug)); ?>"><?php echo e($rates->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$rates->slug)); ?>"><?php echo e($rates->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($rates->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 100%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->

                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- End .owl-carousel -->
                    </div><!-- .End .tab-pane -->
                    <div class="tab-pane p-0 fade" id="trending-new-tab" role="tabpanel" aria-labelledby="trending-new-link">
                        <div class="row">
                            <?php if(!empty($get_new)): ?>
                            <?php $__currentLoopData = $get_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2 col-4">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-new">New</span>
                                    <a href="<?php echo e(url('/product/'.$new->slug)); ?>">
                                        <img src="<?php echo e($new->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" class="btn-product-icon btn-wishlist" onclick="addToWishList(<?php echo $new->id; ?>)" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" class="btn-product btn-cart" onclick="addToCart(<?php echo $new->id; ?>)" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$new->category_slug)); ?>"><?php echo e($new->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$new->slug)); ?>"><?php echo e($new->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($new->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 80%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->
                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- End .owl-carousel -->
                    </div><!-- .End .tab-pane -->
                </div><!-- End .tab-content -->
            </div><!-- End .col-xl-4-5col -->
        </div><!-- End .row -->
    </div><!-- End .container -->
</div><!-- End .bg-light pt-5 pb-6 -->
<div class="py-5" style="background: url('public/assets/images/green-slide-01.jpg') center center; ">
<div class="container pt-5">
    
    
    <div class="row justify-content-center">
            <div class="col-lg-4 col-sm-6">
                <div class="icon-box icon-box-left icon-box-circle">
                    <span class="icon-box-icon">
                        <img src="assets/images/home1-payment-1.png" alt=""/>
                    </span>
                    <div class="icon-box-content">
                      <h3 class="icon-box-title text-white font-weight-bold">Free Shipping on above Rs.1000</h3><!-- End .icon-box-title -->
                        <p class="text-white">Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus augue.</p>
                  </div><!-- End .icon-box-content -->
              </div><!-- End .icon-box -->
            </div><!-- End .col-lg-4 col-sm-6 -->

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box icon-box-left icon-box-circle">
                    <span class="icon-box-icon">
                        <img src="<?php echo e(url('/public/assets/images/home1-payment-3.png')); ?>" alt=""/>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title text-white font-weight-bold">10% Off the Bill</h3><!-- End .icon-box-title -->
                        <p class="text-white">Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate eu erat. </p>
                    </div><!-- End .icon-box-content -->
                </div><!-- End .icon-box -->
            </div><!-- End .col-lg-4 col-sm-6 -->

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box icon-box-left icon-box-circle">
                    <span class="icon-box-icon">
                        <img src="<?php echo e(url('/public/assets/images/home1-payment-2.png')); ?>" alt=""/>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title text-white font-weight-bold">Security Payment</h3><!-- End .icon-box-title -->
                        <p class="text-white">Pellentesque a diam sit amet vehicula. Nullam quis massa sit amet nibh viverra malesuada.</p>
                    </div><!-- End .icon-box-content -->
                </div><!-- End .icon-box -->
            </div><!-- End .col-lg-4 col-sm-6 -->
        </div>
</div><!-- End .container -->
</div>
<div class="mb-4"></div><!-- End .mb-4 -->
<div class="pt-2 pb-6">
    <div class="container trending-products">
        <div class="heading heading-flex mb-3">
            <div class="heading-left">
                <h2 class="title">New Arrivals</h2><!-- End .title -->
            </div><!-- End .heading-left -->

           <div class="heading-right">
                <ul class="nav nav-pills nav-border-anim justify-content-center" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="trending-top-link" data-toggle="tab" href="#trending-top-tab" role="tab" aria-controls="trending-top-tab" aria-selected="true">Top Rated</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="trending-best-link" data-toggle="tab" href="#trending-best-tab" role="tab" aria-controls="trending-best-tab" aria-selected="false">Best Selling</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="trending-sale-link" data-toggle="tab" href="#trending-sale-tab" role="tab" aria-controls="trending-sale-tab" aria-selected="false">On Sale</a>
                    </li>
                </ul>
           </div><!-- End .heading-right -->
        </div><!-- End .heading -->

        <div class="row">
            <div class="col-xl-5col d-none d-xl-block">
                <div class="banner">
                    <table class="table table-wishlist table-mobile" style="background: #fff;">

            <tbody>
                <?php if($get_arrivals->total() > 0): ?>
                <?php $__currentLoopData = $get_arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrivals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="product-col pl-3">
                        <div class="product">
                            <figure class="product-media">
                                <a href="<?php echo e(url('/product/'.$arrivals->slug)); ?>">
                                    <img src="<?php echo e($arrivals->product_img); ?>" alt="Product image">
                                </a>
                            </figure>
                            <h3 class="product-title">
                                <a href="<?php echo e(url('/product/'.$arrivals->slug)); ?>"><?php echo e($arrivals->name ?? ''); ?><br><?php echo e(format_money($arrivals->mrp_price)); ?></a>
                            </h3><!-- End .product-title -->
                        </div><!-- End .product -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
                </div><!-- End .banner -->
            </div><!-- End .col-xl-5col -->

            <div class="col-xl-4-5col">
                <div class="tab-content tab-content-carousel just-action-icons-sm">
                    <div class="tab-pane p-0 fade show active" id="trending-top-tab" role="tabpanel" aria-labelledby="trending-top-link">
                        <div class="owl-carousel owl-full carousel-equal-height carousel-with-shadow" data-toggle="owl" 
                            data-owl-options='{
                                "nav": true, 
                                "dots": false,
                                "margin": 20,
                                "loop": false,
                                "responsive": {
                                    "0": {
                                        "items":2
                                    },
                                    "480": {
                                        "items":2
                                    },
                                    "768": {
                                        "items":3
                                    },
                                    "992": {
                                        "items":4
                                    }
                                }
                            }'>
                            <?php if($get_best_rates->total() > 0): ?>
                            <?php $__currentLoopData = $get_best_rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-top">Top</span>
                                    <a href="<?php echo e(url('/product/'.$best->slug)); ?>">
                                        <img src="<?php echo e($best->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" onclick="addToWishList(<?php echo $best->id; ?>)" class="btn-product-icon btn-wishlist" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" onclick="addToCart(<?php echo $best->id; ?>)" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$best->category_slug)); ?>"><?php echo e($best->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$best->slug)); ?>"><?php echo e($best->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($best->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 100%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->

                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- End .owl-carousel -->
                    </div><!-- .End .tab-pane -->
                    <div class="tab-pane p-0 fade" id="trending-best-tab" role="tabpanel" aria-labelledby="trending-best-link">
                        <div class="owl-carousel owl-full carousel-equal-height carousel-with-shadow" data-toggle="owl" 
                            data-owl-options='{
                                "nav": true, 
                                "dots": false,
                                "margin": 20,
                                "loop": false,
                                "responsive": {
                                    "0": {
                                        "items":2
                                    },
                                    "480": {
                                        "items":2
                                    },
                                    "768": {
                                        "items":3
                                    },
                                    "992": {
                                        "items":4
                                    }
                                }
                            }'>
                            <?php $__currentLoopData = $get_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gdeals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-new">New</span>
                                    <a href="<?php echo e(url('/product/'.$gdeals->slug)); ?>">
                                        <img src="<?php echo e($gdeals->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" onclick="addToWishList(<?php echo $gdeals->id; ?>)" class="btn-product-icon btn-wishlist" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" onclick="addToCart(<?php echo $gdeals->id; ?>)" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category'.$gdeals->category_slug)); ?>"><?php echo e($gdeals->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$gdeals->slug)); ?>"><?php echo e($gdeals->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        <?php echo e(format_money($gdeals->mrp_price)); ?>

                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 80%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->

                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- End .owl-carousel -->
                    </div><!-- .End .tab-pane -->
                    <div class="tab-pane p-0 fade" id="trending-sale-tab" role="tabpanel" aria-labelledby="trending-sale-link">
                        <div class="owl-carousel owl-full carousel-equal-height carousel-with-shadow" data-toggle="owl" 
                            data-owl-options='{
                                "nav": true, 
                                "dots": false,
                                "margin": 20,
                                "loop": false,
                                "responsive": {
                                    "0": {
                                        "items":2
                                    },
                                    "480": {
                                        "items":2
                                    },
                                    "768": {
                                        "items":3
                                    },
                                    "992": {
                                        "items":4
                                    }
                                }
                            }'>
                            <?php if($get_all_savers->total() > 0): ?>
                            <?php $__currentLoopData = $get_all_savers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product product-2">
                                <figure class="product-media">
                                    <span class="product-label label-circle label-new">New</span>
                                    <a href="<?php echo e(url('/product/'.$save->slug)); ?>">
                                        <img src="<?php echo e($save->product_img); ?>" alt="Product image" class="product-image">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="javascript::void(0)" onclick="addToWishList(<?php echo $save->id; ?>)" class="btn-product-icon btn-wishlist" title="Add to wishlist"></a>
                                    </div><!-- End .product-action -->

                                    <div class="product-action">
                                        <a href="javascript::void(0)" onclick="addToCart(<?php echo $save->id; ?>)" class="btn-product btn-cart" title="Add to cart"><span>add to cart</span></a>
                                        
                                    </div><!-- End .product-action -->
                                </figure><!-- End .product-media -->

                                <div class="product-body">
                                    <div class="product-cat">
                                        <a href="<?php echo e(url('/all_products/category/'.$save->category_slug)); ?>"><?php echo e($save->category_name ?? ''); ?></a>
                                    </div><!-- End .product-cat -->
                                    <h3 class="product-title"><a href="<?php echo e(url('/product/'.$save->slug)); ?>"><?php echo e($save->name ?? ''); ?></a></h3><!-- End .product-title -->
                                    <div class="product-price">
                                        
                                    </div><!-- End .product-price -->
                                    <div class="ratings-container">
                                        <div class="ratings">
                                            <div class="ratings-val" style="width: 80%;"></div><!-- End .ratings-val -->
                                        </div><!-- End .ratings -->
                                        <span class="ratings-text">( 4 Reviews )</span>
                                    </div><!-- End .rating-container -->

                                    
                                </div><!-- End .product-body -->
                            </div><!-- End .product -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- End .owl-carousel -->
                    </div><!-- .End .tab-pane -->
                </div><!-- End .tab-content -->
            </div><!-- End .col-xl-4-5col -->
        </div><!-- End .row -->
    </div><!-- End .container -->
</div><!-- End .bg-light pt-5 pb-6 -->
<div class="mb-4"></div><!-- End .mb-4 -->
<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/welcome.blade.php ENDPATH**/ ?>
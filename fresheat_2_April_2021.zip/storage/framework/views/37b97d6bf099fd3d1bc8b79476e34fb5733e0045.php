  <?php
    $total_amount = $order->payable_price * 100;
    $icon_url = url('public/assets/images/demos/demo-4/logo.png');

  ?>
  <script src="<?php echo e(url('/public/')); ?>/assets/js/jquery.min.js"></script>
  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
  <script type="text/javascript">

        var name = "<?php echo e($order->name); ?>";
        var email = "<?php echo e($order->email); ?>";
        var phone = "<?php echo e($order->phone); ?>";
        var country = "<?php echo e($order->country); ?>";
        var state = "<?php echo e($order->state); ?>";
        var city = "<?php echo e($order->city); ?>";
        var pincode = "<?php echo e($order->pincode); ?>";
        var address = "<?php echo e($order->street); ?>";
        var order_note = "<?php echo e($order->order_note); ?>";
        var ordr_id = "<?php echo e($order->id); ?>";
        var base_url = "<?php echo e(url('/')); ?>";

        var options = {
              key: "rzp_test_W4ryNkrfoJ3NRx",
              amount: "<?php echo e($total_amount); ?>",
              prefill: {
                  name: '<?php echo e($order->name); ?>',
                  email: '<?php echo e($order->email); ?>',
                  contact: '<?php echo e($order->phone); ?>'
              },
              theme: {
               color: "#008A73"
              },
              name: 'Fresh Eat',
              description: "Your orders",
              image: "<?php echo e($icon_url); ?>",
              handler: razorpay_actionhandler,
              modal: { escape: false, 
                ondismiss: function(){ 
                  window.location.href = base_url+'/checkout/<?php echo e($order->order_id); ?>';
              } },
          }
          window.r = new Razorpay(options);
          r.open()  


  function razorpay_actionhandler(response){
      $.ajax({
           url: "<?php echo e(url('order_success')); ?>",
           type: 'post',
           dataType: 'json',
            data: {
            amount: "<?php echo e($total_amount); ?>",
            razorpay_payment_id: response.razorpay_payment_id ,
              order_id : ordr_id,
             _token: "<?php echo e(@csrf_token()); ?>",
           }, 
           success: function (msg) {
                window.location.href = "<?php echo e(url('thankyou')); ?>"
           }
      });
  }
  </script>
<?php /**PATH E:\xampp\htdocs\fresheat\resources\views/includes/new-user-checkout.blade.php ENDPATH**/ ?>
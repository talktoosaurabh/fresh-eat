<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Create Coupons</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php if(Session::has('flash_success')): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_success')); ?>

                  </div>
              <?php endif; ?>
              <?php if(Session::has('flash_error')): ?>
                  <div class="alert alert-danger">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_error')); ?>

                  </div>
              <?php endif; ?>
              <form role="form" id="myform" method="post" action="<?php echo e(route('coupons.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="container">
                 <div class="row">
                    <div class="col-sm-12">
                          <div class="form-group">
                            <label for="price">Coupon Code <span class="required">*</span></label>
                            <input type="text" name="coupon_code" id="coupon_code" class="form-control" placeholder="Enter Coupon Code" />
                            <?php if($errors->has('coupon_code')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('coupon_code')); ?></strong>
                                </span>
                            <?php endif; ?>  
                          </div>
                          <div>
                            <label for="discount_type">Discount Type <span class="required">*</span></label><br>
                            <label for="chkYes">
                              <input type="radio" class="discount_type" value="Percentage" name="discount_type" checked />
                              <?php if($errors->has('discount_type')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('discount_type')); ?></strong>
                                </span>
                              <?php endif; ?>  
                              Percentage
                            </label>
                            <label for="chkNo">
                              <input type="radio" class="discount_type" value="Flat" name="discount_type" />
                              <?php if($errors->has('discount_type')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('discount_type')); ?></strong>
                                </span>
                              <?php endif; ?>  
                              Flat
                            </label>
                          </div>
                          <div>
                              <label for="price">Status <span class="required">*</span></label><br>
                                <label for="chkYes">
                                  <input type="radio" class="status" value="Active" name="status" checked />
                                  <?php if($errors->has('status')): ?>
                                    <span class="required">
                                        <strong><?php echo e($errors->first('status')); ?></strong>
                                    </span>
                                  <?php endif; ?>  
                                  Active
                                </label>
                              <label for="chkNo">
                                  <input type="radio" class="status" value="InActive" name="status" />
                                  <?php if($errors->has('status')): ?>
                                    <span class="required">
                                        <strong><?php echo e($errors->first('status')); ?></strong>
                                    </span>
                                  <?php endif; ?>  
                                  InActive
                              </label>
                          </div>
                            <div class="form-group">
                             <label for="percentage">Discount Amount <span class="required">*</span></label>
                                <input type="number" name="discount_amount" id="discount_amount" class="form-control" min="1" placeholder="Enter Discount Amount"  />
                                <?php if($errors->has('discount_amount')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('discount_amount')); ?></strong>
                                </span>
                            <?php endif; ?>  
                            </div>
                            <div class="form-group">
                             <label for="flat">Apply On Minimum Order Amount <span class="required">*</span></label>
                                <input type="number" id="minimum_order" name="minimum_order" class="form-control" min="1" style="background: white;" placeholder="Enter Minimum Order Amount"/>
                                <?php if($errors->has('minimum_order')): ?>
                                <span class="required">
                                    <strong><?php echo e($errors->first('minimum_order')); ?></strong>
                                </span>
                            <?php endif; ?>  
                            </div>
                            <div class="form-group">
                              <label for="price">Valid Till <span class="required">*</span></label>
                              <input type="text" name="validity_till" class="form-control" id="datepicker1" placeholder="Vaild Till" />
                              <?php if($errors->has('validity_till')): ?>
                                  <span class="required">
                                      <strong><?php echo e($errors->first('validity_till')); ?></strong>
                                  </span>
                              <?php endif; ?>  
                            </div>
                           <div class="form-group">
                            <button id="submit" type="submit" class="btn btn-primary">Create Coupon</button>
                          </div>
                    </div>
                 </div>
                </div>
              </form>
          </div>
        </div>
       </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<script>
  $( function() {
    $( "#datepicker" ).datepicker({  
        minDate: new Date(),
        dateFormat: 'yy-mm-dd', 
    });
    $( "#datepicker1" ).datepicker({  
        minDate: new Date(),
        dateFormat: 'yy-mm-dd', 
    });
  });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/coupons/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="content">
  <div class="container-fluid">
     <!-- Main content -->
    <section class="content">
     
    </section>
    <!-- /.content -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/home.blade.php ENDPATH**/ ?>
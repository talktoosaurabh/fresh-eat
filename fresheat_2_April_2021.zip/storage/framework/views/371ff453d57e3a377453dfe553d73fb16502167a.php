<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Products</h3>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary float-right">Create</a>
              </div>
              <?php if(Session::has('flash_success')): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                  <?php echo e(Session::get('flash_success')); ?>

                  </div>
              <?php endif; ?>
              <!-- /.card-header -->
              <div class="card-body">
                <table class="table table-bordered">
                  <thead>                  
                    <tr>
                      <th>Image</th>
                      <th>Name</th>
                      <th>Stock(in weight)</th>
                      <th>Mrp Price</th>
                      <th>Weight</th>
                      <th>Status</th>
                      <th>Category</th>
                      <th>Subategory</th>
                      <th>Action</th>
                    </tr> 
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    $productImage = \App\Models\ProductsImage::where('products_id',$row->id)->where('is_featured',1)->first(); 
                    $category = \App\Models\Category::where('id',$row->category_id)->first();
                    $subcategory = \App\Models\Category::where('id',$row->subcategory_id)->first();
                    ?>
                    <tr>
                      <td>
                        <img src="<?php echo e(URL::to('/')); ?>/public/assets/images/products/<?php echo e(@$productImage->image); ?>" style="width: 100px;" />
                      </td>
                      <td><?php echo e(@$row->name); ?></td>
                      <td><?php echo e($row->stock_count.' kg'); ?></td>
                      <td>&#x20B9;<?php echo e(@$row->mrp_price); ?></td>
                      <td><?php echo e(@$row->weight.' '.@$row->weight_units); ?></td>
                      <td><?php echo e(@$row->status); ?></td>
                      
                      <td><?php echo e(@$category->name); ?></td>
                      <td>
                          <?php echo e(@$subcategory->name); ?>

                      </td>
                      <td>
                        <a href="<?php echo e(route('products.edit', $row->id)); ?>" class="btn"><i class="fas fa-edit" style="color: blue;"></i></a>
                        <button form="resource-delete-<?php echo e($row->id); ?>"><i style="color: red;" class="fas fa-trash-alt"></i></button>
                        <form id="resource-delete-<?php echo e($row->id); ?>" action="<?php echo e(route('products.destroy', $row->id)); ?>" style="display: inline-block;" onSubmit="return confirm('Are you sure you want to delete this item?');" method="post">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                        </form>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <br>
                <?php echo $data->links(); ?>

              </div>
              <!-- /.card-body -->
              
        </div>
        <!-- /.card -->
        </div>
       </div>
      </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\fresheat\resources\views/admin/products/index.blade.php ENDPATH**/ ?>